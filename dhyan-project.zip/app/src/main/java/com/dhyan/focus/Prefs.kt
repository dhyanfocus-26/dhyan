package com.dhyan.focus

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("dhyan", Context.MODE_PRIVATE)

    fun allowedApps(c: Context): MutableSet<String> = sp(c).getStringSet("apps", emptySet())!!.toMutableSet()
    fun setAllowedApps(c: Context, s: Set<String>) = sp(c).edit().putStringSet("apps", s).apply()

    // ভিডিও: "id|নাম" প্রতি লাইনে একটা
    fun videos(c: Context): MutableList<Pair<String, String>> =
        sp(c).getString("videos", "")!!.split("\n").filter { it.isNotBlank() }
            .map { val p = it.split("|", limit = 2); p[0] to p.getOrElse(1) { "" } }.toMutableList()
    fun setVideos(c: Context, l: List<Pair<String, String>>) =
        sp(c).edit().putString("videos", l.joinToString("\n") { "${it.first}|${it.second}" }).apply()

    fun lockEnd(c: Context) = sp(c).getLong("lockEnd", 0L)
    fun lockMinutes(c: Context) = sp(c).getInt("lockMin", 0)
    fun startLock(c: Context, minutes: Int) =
        sp(c).edit().putLong("lockEnd", System.currentTimeMillis() + minutes * 60_000L).putInt("lockMin", minutes).apply()
    fun clearLock(c: Context) = sp(c).edit().putLong("lockEnd", 0L).apply()
    fun isLocked(c: Context) = lockEnd(c) > System.currentTimeMillis()

    fun totalMinutes(c: Context) = sp(c).getInt("total", 0)
    fun addMinutes(c: Context, m: Int) = sp(c).edit().putInt("total", totalMinutes(c) + m).apply()

    fun goalName(c: Context) = sp(c).getString("gName", "") ?: ""
    fun goalStart(c: Context) = sp(c).getLong("gStart", 0L)
    fun goalMonths(c: Context) = sp(c).getInt("gMonths", 1)
    fun setGoal(c: Context, name: String, months: Int) =
        sp(c).edit().putString("gName", name).putLong("gStart", System.currentTimeMillis()).putInt("gMonths", months).apply()
}
