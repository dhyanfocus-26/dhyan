package com.dhyan.focus

import android.Manifest
import android.app.AppOpsManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var root: LinearLayout
    private var minutes = 45
    private var timerView: TextView? = null
    private var quitLeft = -1
    private val BAD = Regex("prank|reaction|vlog|shorts|roast|meme|funny|tiktok|reels|ফান|প্র্যাঙ্ক|রোস্ট|মিম", RegexOption.IGNORE_CASE)

    private val tick = object : Runnable {
        override fun run() {
            if (Prefs.isLocked(this@MainActivity)) {
                val s = (Prefs.lockEnd(this@MainActivity) - System.currentTimeMillis()) / 1000
                timerView?.text = String.format("%02d:%02d", s / 60, s % 60)
                h.postDelayed(this, 500)
            } else if (timerView != null) { timerView = null; render() }
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val sv = ScrollView(this).apply { setBackgroundColor(Color.parseColor("#F4F7F6")) }
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 60) }
        sv.addView(root); setContentView(sv)
        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    override fun onResume() {
        super.onResume()
        if (Prefs.isLocked(this)) startForegroundService(Intent(this, FocusService::class.java))
        render()
    }
    override fun onPause() { h.removeCallbacks(tick); super.onPause() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun text(t: String, size: Float = 16f, bold: Boolean = false, col: String = "#10201F") =
        TextView(this).apply {
            text = t; textSize = size; setTextColor(Color.parseColor(col))
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(6), 0, dp(6))
        }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
    private fun section(t: String) { root.addView(text(t, 20f, true, "#0F766E").apply { setPadding(0, dp(22), 0, dp(6)) }) }

    private fun hasUsage(): Boolean {
        val a = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        return a.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }

    private fun render() {
        root.removeAllViews()
        root.addView(text("ধ্যান", 32f, true))
        root.addView(text("লক চালু থাকলে শুধু অনুমোদিত অ্যাপ ও ভিডিও চলবে।", 15f, false, "#55696A"))

        // অনুমতি
        if (!hasUsage()) {
            section("অনুমতি লাগবে")
            root.addView(text("কোন অ্যাপ খোলা আছে তা জানতে “Usage access” দিন।"))
            root.addView(btn("Usage access চালু করুন") { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) })
        }
        if (!Settings.canDrawOverlays(this)) {
            root.addView(text("ব্লক স্ক্রিন দেখাতে “অন্য অ্যাপের ওপর দেখান” দিন।"))
            root.addView(btn("Overlay অনুমতি দিন") {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            })
        }

        // সেশন
        section("১. সেশন টাইমার")
        if (Prefs.isLocked(this)) {
            timerView = text("", 52f, true, "#0F766E").apply { gravity = android.view.Gravity.CENTER }
            root.addView(timerView)
            val quit = Button(this)
            quit.text = if (quitLeft < 0) "আগে বন্ধ করতে চাই" else "অপেক্ষা করুন: $quitLeft সেকেন্ড (চাপলে বাতিল)"
            quit.setOnClickListener { toggleQuit() }
            root.addView(quit)
            h.removeCallbacks(tick); h.post(tick)
        } else {
            val row = LinearLayout(this)
            listOf(25, 45, 60, 90).forEach { m ->
                row.addView(Button(this).apply {
                    text = "$m মি."; alpha = if (m == minutes) 1f else 0.5f
                    setOnClickListener { minutes = m; render() }
                }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            }
            root.addView(row)
            root.addView(btn("লক চালু করুন ($minutes মিনিট)") { startLock() })
            root.addView(text("আজ পর্যন্ত মোট ফোকাস: ${Prefs.totalMinutes(this)} মিনিট", 14f, false, "#55696A"))
        }

        // টাস্ক
        section("২. টাস্ক লক্ষ্য (১–২ মাস)")
        val gs = Prefs.goalStart(this)
        if (gs > 0) {
            val total = Prefs.goalMonths(this) * 30
            val day = ((System.currentTimeMillis() - gs) / 86_400_000L).toInt().coerceIn(0, total)
            root.addView(text("“${Prefs.goalName(this)}” · দিন $day / $total"))
            root.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = total; progress = day })
        }
        val gn = EditText(this).apply { hint = "লক্ষ্যের নাম (যেমন: ইংরেজি কোর্স শেষ)" }
        root.addView(gn)
        val row2 = LinearLayout(this)
        listOf(1, 2).forEach { m ->
            row2.addView(btn("$m মাসের লক্ষ্য") {
                if (gn.text.isNotBlank()) { Prefs.setGoal(this, gn.text.toString().trim(), m); render() }
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        root.addView(row2)

        // অনুমোদিত অ্যাপ
        section("৩. অনুমোদিত অ্যাপ")
        root.addView(text("লকের সময় শুধু টিক দেওয়া অ্যাপ খুলবে। বাকি সব বন্ধ।", 14f, false, "#55696A"))
        val allowed = Prefs.allowedApps(this)
        val apps = packageManager.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
        apps.forEach { ri ->
            val pkg = ri.activityInfo.packageName
            root.addView(CheckBox(this).apply {
                text = ri.loadLabel(packageManager); isChecked = pkg in allowed
                setTextColor(Color.parseColor("#10201F"))
                setOnCheckedChangeListener { _, on ->
                    val s = Prefs.allowedApps(this@MainActivity); if (on) s.add(pkg) else s.remove(pkg)
                    Prefs.setAllowedApps(this@MainActivity, s)
                }
            })
        }

        // অনুমোদিত ভিডিও
        section("৪. অনুমোদিত ভিডিও")
        val url = EditText(this).apply { hint = "YouTube লিংক"; inputType = InputType.TYPE_TEXT_VARIATION_URI }
        val title = EditText(this).apply { hint = "ভিডিওর নাম" }
        val err = text("", 14f, false, "#B42318")
        root.addView(url); root.addView(title); root.addView(err)
        root.addView(btn("তালিকায় যোগ করুন") {
            val m = Regex("(?:youtu\\.be/|v=|embed/|shorts/)([A-Za-z0-9_-]{11})").find(url.text.toString())
            val t = title.text.toString().replace("|", " ").replace("\n", " ").trim()
            when {
                m == null -> err.text = "সঠিক YouTube লিংক দিন।"
                t.isEmpty() -> err.text = "ভিডিওর একটা নাম দিন।"
                BAD.containsMatchIn(t + " " + url.text) -> err.text = "এটা শিক্ষামূলক মনে হচ্ছে না, যোগ হলো না।"
                else -> {
                    val l = Prefs.videos(this); l.add(m.groupValues[1] to t); Prefs.setVideos(this, l); render()
                }
            }
        })
        Prefs.videos(this).forEachIndexed { i, v ->
            val r = LinearLayout(this).apply { gravity = android.view.Gravity.CENTER_VERTICAL }
            r.addView(text(v.second), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            r.addView(btn("▶") { startActivity(Intent(this, PlayerActivity::class.java).putExtra("id", v.first)) })
            r.addView(btn("মুছুন") { val l = Prefs.videos(this); l.removeAt(i); Prefs.setVideos(this, l); render() })
            root.addView(r)
        }
    }

    private fun startLock() {
        if (!hasUsage() || !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "আগে ওপরের দুটো অনুমতি দিন।", Toast.LENGTH_LONG).show(); return
        }
        Prefs.startLock(this, minutes)
        startForegroundService(Intent(this, FocusService::class.java))
        render()
    }

    // আগে বন্ধ করতে ৬০ সেকেন্ড অপেক্ষা
    private fun toggleQuit() {
        if (quitLeft >= 0) { quitLeft = -1; h.removeCallbacksAndMessages("q"); render(); return }
        quitLeft = 60
        val step = object : Runnable {
            override fun run() {
                if (quitLeft < 0) return
                quitLeft--
                if (quitLeft <= 0) {
                    quitLeft = -1; Prefs.clearLock(this@MainActivity)
                    stopService(Intent(this@MainActivity, FocusService::class.java)); render()
                } else { render(); h.postDelayed(this, 1000) }
            }
        }
        render(); h.postDelayed(step, 1000)
    }
}
