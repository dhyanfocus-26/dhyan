package com.dhyan.focus

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper

class FocusService : Service() {
    private val h = Handler(Looper.getMainLooper())
    private var lastPkg = ""
    private val always = HashSet<String>()

    private val tick = object : Runnable {
        override fun run() {
            if (!Prefs.isLocked(this@FocusService)) { finishLock(); return }
            check()
            h.postDelayed(this, 1000)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val ch = "dhyan_lock"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(ch, "ফোকাস লক", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, ch).setContentTitle("ধ্যান: ফোকাস চলছে")
            .setContentText("শুধু অনুমোদিত অ্যাপ চলবে").setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentIntent(open).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)

        always.clear()
        always.add("com.android.systemui")
        packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
            .forEach { always.add(it.activityInfo.packageName) }
        packageManager.queryIntentActivities(Intent(Intent.ACTION_DIAL), 0)
            .forEach { always.add(it.activityInfo.packageName) }

        h.removeCallbacks(tick)
        h.post(tick)
        return START_STICKY
    }

    private fun check() {
        val um = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val ev = um.queryEvents(now - 10_000, now)
        val e = UsageEvents.Event()
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) lastPkg = e.packageName
        }
        if (lastPkg.isEmpty() || lastPkg == packageName || lastPkg in always) return
        if (lastPkg in Prefs.allowedApps(this)) return
        startActivity(Intent(this, BlockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
    }

    private fun finishLock() {
        val m = Prefs.lockMinutes(this)
        if (Prefs.lockEnd(this) != 0L) Prefs.addMinutes(this, m)   // সময় পূর্ণ হলে জমা
        Prefs.clearLock(this)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() { h.removeCallbacks(tick); super.onDestroy() }
}
