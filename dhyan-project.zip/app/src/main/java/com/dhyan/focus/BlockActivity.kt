package com.dhyan.focus

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

class BlockActivity : AppCompatActivity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var left: TextView

    private val tick = object : Runnable {
        override fun run() {
            val s = (Prefs.lockEnd(this@BlockActivity) - System.currentTimeMillis()) / 1000
            if (s <= 0) { finish(); return }
            left.text = String.format("%02d:%02d", s / 60, s % 60)
            h.postDelayed(this, 500)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#0F2F2C")); setPadding(64, 64, 64, 64)
        }
        fun tv(t: String, size: Float, col: String) = TextView(this).apply {
            text = t; textSize = size; setTextColor(Color.parseColor(col)); gravity = Gravity.CENTER
        }
        root.addView(tv("এখন ফোকাস সময়", 28f, "#F3EDDC"))
        left = tv("", 56f, "#2DD4BF"); root.addView(left)
        root.addView(tv("এই অ্যাপ এখন বন্ধ। এর মধ্যে শিখুন, পরে বিনোদন।", 16f, "#B9D3CE"))
        root.addView(Button(this).apply {
            text = "ফোকাস অ্যাপে ফিরুন"
            setOnClickListener { startActivity(Intent(this@BlockActivity, MainActivity::class.java)); finish() }
        })
        setContentView(root)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        })
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { h.removeCallbacks(tick); super.onPause() }
}
