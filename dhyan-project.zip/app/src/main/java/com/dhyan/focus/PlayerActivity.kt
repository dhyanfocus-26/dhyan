package com.dhyan.focus

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

// শুধু অনুমোদিত ভিডিও চলে। সাজেশন নেই (rel=0), অন্য লিংকে যাওয়া বন্ধ।
class PlayerActivity : AppCompatActivity() {
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val id = intent.getStringExtra("id") ?: return finish()
        val w = WebView(this)
        w.settings.javaScriptEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean =
                !(r.url.host ?: "").endsWith("youtube-nocookie.com")
        }
        val html = """<html><body style="margin:0;background:#000"><iframe width="100%" height="100%"
            src="https://www.youtube-nocookie.com/embed/$id?rel=0&modestbranding=1&playsinline=1"
            frameborder="0" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen></iframe></body></html>"""
        w.loadDataWithBaseURL("https://www.youtube-nocookie.com", html, "text/html", "utf-8", null)
        setContentView(w)
    }
}
